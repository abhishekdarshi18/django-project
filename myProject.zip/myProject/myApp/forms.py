from django import forms
from .models import User

class CarRegistration(forms.ModelForm):
    class Meta:
        model = User
        fields = ['name', 'engine', 'max_speed', 'avg_speed', 'year']
        widgets = {
        'name' : forms.TextInput(attrs={'class' : 'forms.control'}),
        'engine' : forms.TextInput(attrs={'class' : 'forms.control'}),
        'max_speed' : forms.TextInput(attrs={'class' : 'forms.control'}),
        'avg_speed' : forms.TextInput(attrs={'class' : 'forms.control'}),
        'year' : forms.TextInput(attrs={'class' : 'forms.control'}),
        }