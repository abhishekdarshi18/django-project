from django.shortcuts import render, HttpResponseRedirect
from .forms import CarRegistration
from .models import User

# Create your views here.

def add_show(request):
    if request.method == 'POST':
        fm = CarRegistration(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            eg = fm.cleaned_data['engine']
            ms = fm.cleaned_data['max_speed']
            av = fm.cleaned_data['avg_speed']
            yr = fm.cleaned_data['year']
            reg = User(name=nm, engine=eg, max_speed=ms, avg_speed=av, year=yr)
            reg.save()
            fm = CarRegistration()
    else:
         fm = CarRegistration()       
    showdata = User.objects.all()
    return render(request, 'myApp/addNew.html' , {'form' : fm, 'swdata' : showdata})
    
# Function to edit and update data

def update_data(request, id):
    if request.method == 'POST' :
        rm = User.objects.get(pk = id)
        fm = CarRegistration(request.POST, instance = rm )
        if fm.is_valid():
            fm.save()
    else:
        rm = User.objects.get(pk=id)
        fm = CarRegistration(instance=rm )       
    return render(request, 'myApp/update_details.html' , {'form': fm})
    
# Function to delete data

def delete_data(request, id):
    if request.method == 'POST' :
        rm = User.objects.get(pk=id)
        rm.delete()
        return HttpResponseRedirect('/')