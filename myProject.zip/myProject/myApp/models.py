from django.db import models

# Create your models here.
class User(models.Model):
    name = models.CharField(max_length=70)
    engine = models.CharField(max_length=100)
    max_speed = models.CharField(max_length=100)
    avg_speed = models.CharField(max_length=100)
    year = models.CharField(max_length=70)